# Exportação de conversas do WhatsApp: Schelbi Basso Pluma
Data de exportação: 21 de outubro de 2026 às 18:00

---

## 16 de julho de 2026

[9:05] **Você:** bom dia , lembrando pra ver o protocolo das ferias lá

[9:05] **Você:** se deu certo

[11:26] **Schelbi Basso Pluma:** Bom dia

[11:26] **Schelbi Basso Pluma:** Ja olho

---

## 17 de julho de 2026

[13:13] **Você:** boa tarde Schellbi

[13:15] **Você:** Queria te contar uma situação que aconteceu e que vem me preocupando.

[13:15] **Você:** A key user falou que o relatório não atendeu às expectativas e reclamou da entrega. Até aí tudo bem, porque faz parte ela avaliar e apontar o que precisa ser corrigido.

[13:16] **Você:** O problema foi a forma como ela colocou isso. Ela disse que não atendeu, mas não explicou claramente o que estava errado, o que precisava ser ajustado e qual era o resultado esperado.

[13:16] **Você:** E percebo que ela não faz isso somente comigo. Ela costuma ter essa mesma postura com outras pessoas, reclamando das entregas sem contribuir de forma objetiva para a solução. Isso acaba desgastando a equipe e dificultando o andamento do projeto.

[13:17] **Você:** ta ficando dificil de lidar com ela

[13:20] **Você:** Depois daquela reunião que tivemos em novembro, eu procurei rever minha postura e mudar a forma de conduzir as situações. Tenho me policiado para agir de maneira mais profissional, evitar conflitos e contribuir para o andamento do projeto.

[13:20] **Você:** Porém, da parte dela, não percebi a mesma mudança. Pelo contrário, considero que a postura piorou.

[13:21] **Você:** Eu entendo perfeitamente que faz parte da função dela avaliar e questionar as entregas. O problema é a forma como isso vem sendo feito. E não acontece somente comigo; percebo essa mesma postura no tratamento com outras pessoas,

[13:21] **Você:** Estou te falando porque essa situação está começando a pesar para mim. Gosto do meu trabalho e sempre procuro entregar o melhor possível, mas também preciso de um ambiente em que exista respeito e colaboração.

[13:22] **Você:** Sendo bem transparente, caso essa situação continue sem nenhuma medida ou alinhamento, vou precisar começar a avaliar outras possibilidades profissionais. Não estou colocando isso como ameaça ou decisão tomada, mas como uma consequência que estou começando a considerar diante do desgaste.

[13:22] **Você:** Queria te deixar ciente e saber como você acha melhor conduzirmos isso.

[13:28] **Schelbi Basso Pluma:** Boa tarde

[13:29] **Schelbi Basso Pluma:** _Mensagem apagada_

[13:30] **Schelbi Basso Pluma:** Qual o nome dela mesmo?

[13:33] **Você:** Camila

[16:41] **Você:** Shellbi, vou prescisar hoje mais cedo 17:15, vou levar minha irmã pra corbelia

[16:41] **Schelbi Basso Pluma:** ok

[16:42] **Schelbi Basso Pluma:** segunda conversamos para alinhar esses assuntos.

[16:42] **Você:** Ok.

[16:42] **Você:** combinado

---

## 31 de julho de 2026

[14:18] __[Ligação]__

[14:18] **Você:** Boa tarde

[14:21] **Schelbi Basso Pluma:** Boa tarde

[14:21] **Você:** Preciso falar com vc

[14:24] __[Ligação]__

---

## 7 de agosto de 2026

[10:26] **Você:** Bom dia,

[10:29] **Você:** Me passaram uma tarefa aqui que tem 18765 passos, , eu já consegui realizar 5345, não consigo terminar hoje

[11:39] **Schelbi Basso Pluma:** Bom dia

[12:06] **Você:** Se você liberar posso concluir no final de semana

[12:07] **Schelbi Basso Pluma:** Beleza

[12:08] **Você:** Obrigado

[12:11] **Schelbi Basso Pluma:** Obrigado voce

[12:11] **Schelbi Basso Pluma:** Me avisa dai

[12:11] **Schelbi Basso Pluma:** Se finalizou

[12:41] **Você:** Sim

---

## 10 de agosto de 2026

[9:34] **Você:** bom dia schellbi , consegui concluir onte aquela tarefa. ja ecaminhei onte mesmo um email avisando os ineteressados

[9:36] **Schelbi Basso Pluma:** Bom dia

[9:36] **Schelbi Basso Pluma:** Li a pouco

[9:36] **Schelbi Basso Pluma:** Obrigado

---

## 13 de agosto de 2026

[8:50] **Schelbi Basso Pluma:** Bom dia Josimesio

[8:50] **Schelbi Basso Pluma:** tudo bem ?

[8:50] **Schelbi Basso Pluma:** Desculpe incomodar.

[8:50] **Schelbi Basso Pluma:** mas estou com uma situação e preciso de ajuda para entender.

[9:02] **Você:** bom dia

[9:02] **Você:** o que aconteceu

[9:02] **Schelbi Basso Pluma:** segundo me passram, falo segundo porque é o que me passaram.

[9:02] **Schelbi Basso Pluma:** não sei se reflete a verdade

[9:03] **Schelbi Basso Pluma:** a tarefa que você finalizou

[9:03] **Schelbi Basso Pluma:** foi executada errada.

[9:03] **Schelbi Basso Pluma:** pedi o porque

[9:03] **Schelbi Basso Pluma:** me passaram isso:

[9:03] **Schelbi Basso Pluma:** Bom dia,

 

Os grupos de aprovação deveriam ter ficado em aberto pelos status do projeto, cada status tem um grupo de aprovação em especifico. Não tem como editar, a alternativa é só refazendo.

[9:03] **Schelbi Basso Pluma:** e segundo o consultor…precisa refazer tudo, não pode alterar.

[9:03] **Você:** tenho um video da orientaçao dele

[9:03] **Você:** gravado e foi feito conforme a orientacao dele

[9:04] **Você:** mas foi feito conforme ele ensinou

[9:08] **Schelbi Basso Pluma:** tem alguem da nossa equipe que acompanhou

[9:08] **Schelbi Basso Pluma:** pra poder me ajudar aqui

[9:08] **Você:** isso eu cuidei muito antes de fazer , já pra não fazer errado

[9:08] **Schelbi Basso Pluma:** tecnicamente não sei o assunto.

[9:08] **Você:** na sala estava eu a Camila e o consultor.

[9:14] **Schelbi Basso Pluma:** não recorda quando foi ?

[9:14] **Você:** sim recordo sim

[9:15] **Você:** foi semana passada

[9:16] **Você:** dentro do CANAL SIT FA PRoject>> REcording >> FLUXO DE APROVACAO

[9:20] **Schelbi Basso Pluma:** que coisa

[9:20] **Schelbi Basso Pluma:** não acho

[9:20] **Schelbi Basso Pluma:** sera que foi gravado ?

[9:24] **Você:** tem sim eu acabei de acessar ela

[9:24] **Schelbi Basso Pluma:** que dia foi ?

[9:29] **Schelbi Basso Pluma:** vou ter que te incomodar mais um pouco

[9:29] **Schelbi Basso Pluma:** infelizmente

[9:29] **Schelbi Basso Pluma:** se precisar, você consegue participar de uma pauta sobre esse assunto ?

[9:29] **Schelbi Basso Pluma:** se tiver condições logicamente.

[9:30] **Você:** consigo sim

[9:30] **Você:** que horas?

[9:31] **Schelbi Basso Pluma:** estou vendo aqui

[9:31] **Schelbi Basso Pluma:** _Mensagem apagada_

[9:31] **Schelbi Basso Pluma:** voce pode que horas?

[9:31] **Você:** pode ser depois das 15

[9:32] **Schelbi Basso Pluma:** claro…deixa ver aqui.

[9:32] **Schelbi Basso Pluma:** 15 é bom ?

[9:32] **Você:** sim

[9:32] **Schelbi Basso Pluma:** deixa ver

[10:13] **Schelbi Basso Pluma:** estou tentando agora as 11

[10:13] **Schelbi Basso Pluma:** ou as 17

[10:13] **Schelbi Basso Pluma:** voce pode nos dois ?

[10:15] **Você:** sim

[10:15] **Schelbi Basso Pluma:** blza

[10:15] **Schelbi Basso Pluma:** agora as 11 então.

[10:15] **Schelbi Basso Pluma:** vou pedir para mandarem

[10:15] **Schelbi Basso Pluma:** muito obrigado pela ajuda.

[10:15] **Você:** ok

[10:15] **Você:**
> _Schelbi Basso Pluma: muito obrigado pela ajuda._
Dnada..

[10:58] **Schelbi Basso Pluma:** recebeu ai ?

[11:01] **Schelbi Basso Pluma:** vai me ajudando ai

[11:01] **Schelbi Basso Pluma:** se te passaram orientação errada

[15:17] **Schelbi Basso Pluma:** Josimesio

[15:17] **Schelbi Basso Pluma:** boa tarde

[15:18] **Você:** Boa tarde

[15:18] **Schelbi Basso Pluma:** se estiver fazendo as alterações, não faz todas

[15:18] **Schelbi Basso Pluma:** sem enviar algumas

[15:18] **Schelbi Basso Pluma:** como combinamos

[15:19] **Você:** A sim, vou alterar conforme combinado

[15:19] **Você:** Apenas algumas para validar primeiro

[15:20] **Você:** Tive que sair resolver umas coisas na rua, lá pelas 16 estou em casa.

[15:22] **Schelbi Basso Pluma:** tranquilo

[17:19] **Você:** boa tarde schellbi

[17:19] **Você:** estão me colocando em agendas amanhã

[17:19] **Schelbi Basso Pluma:** Boa tarde

[17:19] **Schelbi Basso Pluma:** você esta de férias.

[17:19] **Schelbi Basso Pluma:** só fa o que combinamos hoje em exceção\

[17:19] **Schelbi Basso Pluma:** faz*

[17:20] **Você:** blz

[17:20] **Você:** ja neguei aqui

[17:20] **Schelbi Basso Pluma:** altera uma amostragem e escreve no grupo do teams da reiunião de hoje cedo

[17:25] **Você:** Tá bom

[17:56] **Você:** opa

[17:56] **Você:** consegue entrar com a gente pra validar os cadastrados agora?

[17:57] **Schelbi Basso Pluma:** daqui a pouco

[17:57] **Schelbi Basso Pluma:** podem iniciar

[17:58] **Você:** ja conlui o cadastro de uma empresa

[17:59] **Schelbi Basso Pluma:** voce vai ligar pro Roberto e Camila ?

[18:00] **Schelbi Basso Pluma:** poderia usar o mesmo canal da reunião dsa manha

[18:01] **Você:** ok

---

## 18 de agosto de 2026

[11:03] **Schelbi Basso Pluma:** Bom dia Josimesio

[11:03] **Schelbi Basso Pluma:** tudo bem ?

[11:08] **Você:** bom dia

[11:08] **Você:** tudo bem sim

[11:09] **Você:** no ultimo lote de configuração

[13:31] **Você:** boa tarde

[13:31] **Você:** Trabalho conlcuido.

[13:32] **Você:** E agora como que voce quer que eu faça com as horas que usei pra fazer ?

[13:40] **Schelbi Basso Pluma:** Boa tarde

[13:40] **Schelbi Basso Pluma:** avisou o pessoal?

[13:40] **Schelbi Basso Pluma:**
> _Você: E agora como que voce quer que eu faça com as horas que usei pra fazer ?_
isso a gente acerta, compensamos com folga…algo nesse sentido

[13:41] **Schelbi Basso Pluma:** não se preocupe que não irá ficar no prejuízo, quantas horas foram ?

[14:15] **Você:**
> _Schelbi Basso Pluma: avisou o pessoal?_
vou avisa-los

[14:18] **Você:**
> _Schelbi Basso Pluma: isso a gente acerta, compensamos com folga…algo nesse sentido_
Perfeito, sem problema! Depois a gente combina certinho a compensação dessas horas com folga.

[14:26] **Você:**
> _Schelbi Basso Pluma: não se preocupe que não irá ficar no prejuízo, quantas horas foram ?_
41h

[14:39] **Schelbi Basso Pluma:** ok

[14:43] **Você:** Avisei por email a equipe.

[14:43] **Schelbi Basso Pluma:** ok

[14:44] **Schelbi Basso Pluma:** muito obrigado.

[14:47] **Você:** Schellbi to desligando aqui a maquina se prescisar de mais alguma coisa é so me avisar, acho que viajar vou só o final de semana

[14:53] **Schelbi Basso Pluma:** ok

[14:53] **Schelbi Basso Pluma:** obrigado.

---

## 25 de setembro de 2026

[7:02] **Você:** Bom dia

[7:02] **Você:** Preciso resolver uma situação do apartamento agora pela manhã. A inquilina está se negando a providenciar o conserto de algumas coisas que foram danificadas, então preciso tratar disso pessoalmente.

Por esse motivo, só conseguirei ir no período da tarde.

[8:15] **Schelbi Basso Pluma:** Bom dia

---

## 2 de outubro de 2026

[13:09] **Você:** Boa tarde

[13:11] **Você:** Tenho dentista agora as 13:30, retorno as 15

[14:12] **Schelbi Basso Pluma:** Boa tarde

[14:12] **Schelbi Basso Pluma:** ok.
